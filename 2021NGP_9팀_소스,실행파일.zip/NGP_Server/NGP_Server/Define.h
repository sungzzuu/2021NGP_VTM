#pragma once
//#define SERVERPORT 9000
#define BUFSIZE 512

#define POTION_TIME 10
#define START_TIME 5