#pragma once

#ifndef __INCLUDE_H__
#define __INCLUDE_H__

#include "Define.h"
#include "Extern.h"
#include "Struct.h"
#include "Function.h"
#include "Enum.h"
#include "AbstractFactory.h"
#include "Functor.h"

#endif // !__INCLUDE_H__
