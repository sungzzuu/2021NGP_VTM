#pragma once
class CSoundMgr
{
public:
	static CSoundMgr* Get_Instance()
	{
		if (nullptr == m_pInstance)
			m_pInstance = new CSoundMgr;

		return m_pInstance;
	}
	static void Destroy_Instance()
	{
		if (m_pInstance)
		{
			delete m_pInstance;
			m_pInstance = nullptr;
		}
	}
public:
	enum CHANNELID { BGM, PLAYER,P_HIT
		,NOR1, NOR2, NOR3, FIRE1, FIRE2, FIRE3, ICE1
		,BLAST1, BLAST2, BLAST3, BLAST4, BLAST5, BLAST6, SHIELD1
		,PRISON1
		,BOSS_JUMP,BOSS_HIT,BOSS_THROW, BOSS_SPIN, BOSS_DASH
		,GOLD1, GOLD2, GOLD3, GOLD4,SUMMON
		,MONSTER, MON_HIT1, MON_HIT2, MON_HIT3
		,ARCHER, ARC_HIT1, ARC_HIT2, ARC_HIT3, ARC_ATT1, ARC_ATT2, ARC_ATT3, ARC_ATT4
		,WIZARD, WI_HIT1, WI_HIT2, WI_HIT3
		,BALL,BALL_HIT1, BALL_HIT2, BALL_HIT3
		,BOSS, EFFECT, UI, MAXCHANNEL 
		
	};
private:
	CSoundMgr();
	~CSoundMgr();

public:
	void Initialize();

	void Release();
public:
	void PlaySound(TCHAR* pSoundKey, CHANNELID eID);
	void PlayBGM(TCHAR* pSoundKey);
	void StopSound(CHANNELID eID);
	void StopAll();

private:
	void LoadSoundFile();

private:
	static CSoundMgr* m_pInstance;
	// ���� ���ҽ� ������ ���� ��ü 
	map<TCHAR*, FMOD_SOUND*> m_mapSound;
	// FMOD_CHANNEL : ����ϰ� �ִ� ���带 ������ ��ü 
	FMOD_CHANNEL* m_pChannelArr[MAXCHANNEL];
	// ���� ,ä�� ��ü �� ��ġ�� �����ϴ� ��ü 
	FMOD_SYSTEM* m_pSystem;

};

