#pragma once

#ifndef __EXTERN_H__
#define __EXTERN_H__

extern HWND g_hWnd;

#endif // !__EXTERN_H__
